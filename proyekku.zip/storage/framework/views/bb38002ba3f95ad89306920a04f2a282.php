<?php $__env->startSection('content'); ?>
    <h1>Halaman Berita</h1>

    <?php $__currentLoopData = $beritas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $berita): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <article class="mt-5">
            <a href="/berita/<?php echo e($berita['slug']); ?>">
                <h2><?php echo e($berita['judul']); ?></h2>
            </a>
            <h3><?php echo e($berita['penulis']); ?></h3>
            <p><?php echo e($berita['konten']); ?></p>
        </article>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\proyekku\resources\views/berita.blade.php ENDPATH**/ ?>