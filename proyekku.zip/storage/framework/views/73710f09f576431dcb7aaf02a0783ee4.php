<?php $__env->startSection('content'); ?>
    <h1>Profile</h1>

    <h3><?php echo e($nama); ?></h3>
    <p><?php echo e($nohp); ?></p>
    <img src="<?php echo e($foto); ?>"
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\proyekku\resources\views/profile.blade.php ENDPATH**/ ?>